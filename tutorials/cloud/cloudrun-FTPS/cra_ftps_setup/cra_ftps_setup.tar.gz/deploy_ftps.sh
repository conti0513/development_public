#!/bin/bash
echo "Deploying FTPS Server..." 