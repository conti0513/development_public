#!/bin/bash
echo "Deploying Cloud Run A..." 