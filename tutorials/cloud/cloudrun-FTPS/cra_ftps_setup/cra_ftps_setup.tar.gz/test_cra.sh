#!/bin/bash
echo "Testing Cloud Run A..." 