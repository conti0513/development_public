#!/bin/bash
echo "Preparing deployment package..." 