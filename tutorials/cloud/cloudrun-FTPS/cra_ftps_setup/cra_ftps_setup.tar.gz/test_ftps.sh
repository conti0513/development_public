#!/bin/bash
echo "Testing FTPS Server..." 