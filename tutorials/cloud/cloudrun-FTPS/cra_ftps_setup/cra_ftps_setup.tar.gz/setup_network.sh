#!/bin/bash
echo "Setting up network..." 